$(function(){
    $('a[href="#home"]').tab('show');
});