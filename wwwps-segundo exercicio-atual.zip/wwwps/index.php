<?php
	header('Location:/relatorio_lista.php');
?>